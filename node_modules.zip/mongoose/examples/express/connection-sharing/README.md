
To run:

- Execute `npm install` from this directory
- Execute `node app.js`
- Navigate to `localhost:8000`
